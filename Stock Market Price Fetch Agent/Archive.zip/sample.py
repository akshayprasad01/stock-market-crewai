import requests
from bs4 import BeautifulSoup
import re
import pandas as pd

def get_football_player_info(player_name):
    """Fetches football player info (stats, club, country) from Google Search."""

    query = f"{player_name} football"  # Simplified query
    url = f"https://www.google.com/search?q={query}"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "html.parser")

        info = {"name": player_name} #start the dictionary with the name

        # Attempt to find club/country information in the "knowledge graph" or similar sections
        knowledge_panel = soup.find("div", class_="kp-wholepage")  # Look for the knowledge graph

        if knowledge_panel:
            #Look for the club
            club_element = knowledge_panel.find("div", string=re.compile(r"(Current club|Team)"))
            if club_element:
                info["club"] = club_element.find_next("div").text.strip()
            #Look for the country
            country_element = knowledge_panel.find("div", string=re.compile(r"(Nationality|Country)"))
            if country_element:
                info["country"] = country_element.find_next("div").text.strip()
        
        tables = soup.find_all("table")
        all_data = []

        for table in tables:
            table_data = []
            rows = table.find_all("tr")
            headers = [th.text.strip() for th in rows[0].find_all("th")] if rows else []
            for row in rows[1:]:
                cells = row.find_all("td")
                row_data = [cell.text.strip() for cell in cells]
                if row_data:
                    table_data.append(row_data)
            if table_data:
                df = pd.DataFrame(table_data, columns=headers if headers else None)
                all_data.append(df)
        if all_data:
            if len(all_data) == 1:
                info["stats"] = all_data[0]
            else:
                info["stats"] = pd.concat(all_data, ignore_index=True)

        return info

    except requests.exceptions.RequestException as e:
        print(f"Error fetching data: {e}")
        return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

if __name__ == "__main__":
    player_name = input("Enter the name of the football player: ")
    player_info = get_football_player_info(player_name)

    if player_info:
        print(f"Information for {player_info['name']}:")
        if "club" in player_info:
            print(f"Club: {player_info['club']}")
        if "country" in player_info:
            print(f"Country: {player_info['country']}")
        if "stats" in player_info:
            print("\nStats:")
            print(player_info['stats'].to_string())
    else:
        print("Could not retrieve information.")
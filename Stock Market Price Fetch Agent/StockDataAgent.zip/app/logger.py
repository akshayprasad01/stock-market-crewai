import logging

logger = logging.getLogger("api_logger")
logger.setLevel(logging.DEBUG)
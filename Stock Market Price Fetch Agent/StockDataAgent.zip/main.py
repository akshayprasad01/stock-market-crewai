from app.fintech import StockData
from app.logger import logger

def get_company_info(company_name: str):
    try:
        company_stockdata = StockData(ticker_symbol=company_name)
        company_info = company_stockdata.get_company_info()
        logger.info(company_info)
        return company_info
    except Exception as e:
        logger.error(f"error in main get_company_info: {e}")


# from yahoo_fin import stock_info as si

# # Get top gainers
# top_gainers = si.get_day_gainers()
# print(top_gainers)